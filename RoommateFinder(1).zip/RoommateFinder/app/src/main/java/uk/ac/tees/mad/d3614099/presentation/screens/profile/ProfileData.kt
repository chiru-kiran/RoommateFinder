package uk.ac.tees.mad.d3614099.presentation.screens.profile

data class ProfileData(
    val name: String = "John Doe",
    val profileImage: Int,
    val gender: String ="M"
)
